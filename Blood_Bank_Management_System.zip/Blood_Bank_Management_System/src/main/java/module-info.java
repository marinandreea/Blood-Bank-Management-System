module com.example.blood_bank_management_system {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires java.desktop;

    opens presentation to javafx.fxml;
    exports presentation;

    opens model to javafx.fxml;
    exports model;

    opens dataAccess to javafx.fxml;
    exports dataAccess;

}