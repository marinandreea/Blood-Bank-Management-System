package presentation;

import connection.ConnectionFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.registeredblooddonors;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class ClientSeeDonors implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private Button searchButton;
    @FXML
    private Button displayButton;
    @FXML
    private TextField blGroupTxtField;
    @FXML
    private TableView<registeredblooddonors> table;
    @FXML
    private TableColumn<registeredblooddonors, Integer> idCol;
    @FXML
    private TableColumn<registeredblooddonors, String> firstNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> lastNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodGroupCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodRhCol;
    @FXML
    private TableColumn<registeredblooddonors, String> phoneNrCol;
    @FXML
    private TableColumn<registeredblooddonors, String> addressCol;
    @FXML
    private TableColumn<registeredblooddonors, String> emailCol;
    @FXML
    private Label label;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<registeredblooddonors> list = FXCollections.observableArrayList();


    public void backButtonOnAction(ActionEvent e){
        clientPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void searchButtonOnAction(ActionEvent e) throws SQLException {

        if(!search()){
            label.setText("There is no donor having this blood group!");
        }
    }

    public void displayButtonOnAction(ActionEvent e) throws SQLException {

        display();
    }

    public void clientPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public boolean search() throws SQLException {
        String bloodGr = blGroupTxtField.getText();

        list.clear();
        query = "SELECT * FROM registeredblooddonors WHERE bloodgroup = '" + bloodGr + "'";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();
        boolean ok = false;

        while (resultSet.next()){
            registeredblooddonors donor = new registeredblooddonors(resultSet.getInt("id"), resultSet.getString("firstname"), resultSet.getString("lastname"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getString("phonenumber"), resultSet.getString("address"), resultSet.getString("email") );
            list.add(donor);
            ok = true;

        }
        table.setItems(list);
        return ok;

    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from registeredblooddonors";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            registeredblooddonors donor = new registeredblooddonors(resultSet.getInt("id"), resultSet.getString("firstname"), resultSet.getString("lastname"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getString("phonenumber"), resultSet.getString("address"), resultSet.getString("email") );
            list.add(donor);
            table.setItems(list);

        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodgroup"));
        bloodRhCol.setCellValueFactory(new PropertyValueFactory<>("bloodrh"));
        phoneNrCol.setCellValueFactory(new PropertyValueFactory<>("phonenumber"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
    }
}
