package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.OrderBlood;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class AdminAccessTableOfOrdersPageController implements Initializable {

    @FXML
    private TableView<OrderBlood> table;
    @FXML
    private TableColumn<OrderBlood, Integer> idCol;
    @FXML
    private TableColumn<OrderBlood, String> firstNameCol;
    @FXML
    private TableColumn<OrderBlood, String> lastNameCol;
    @FXML
    private TableColumn<OrderBlood, Integer> idBloodCol;
    @FXML
    private TableColumn<OrderBlood, Integer> stockCol;
    @FXML
    private TableColumn<OrderBlood, String> contactNumberCol;
    @FXML
    private TableColumn<OrderBlood, String> addressCol;
    @FXML
    private Button listButton;
    @FXML
    private Button backButton;
    @FXML
    private Button orderButton;
    @FXML
    private Label label;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    GenericDAO<OrderBlood> genericDAO = new GenericDAO<>();

    ObservableList<OrderBlood> list = FXCollections.observableArrayList();



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            loadData();
            label.setText(" ");
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void listButtonOnAction(ActionEvent e) throws SQLException {
        list.clear();
        query = "SELECT * from orderblood";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            OrderBlood blood = new OrderBlood(resultSet.getInt("idorder"), resultSet.getString("firstname"), resultSet.getString("lastname"),resultSet.getInt("idbloodgroup"), resultSet.getInt("stock"), resultSet.getString("contactnumber"), resultSet.getString("address") );
            list.add(blood);
            table.setItems(list);

        }
    }

    public void orderButtonOnAction(ActionEvent e){

        deleteOrder();


    }

    public void deleteOrder(){

        OrderBlood order = table.getSelectionModel().getSelectedItem();
        genericDAO.delete(order);
        label.setText("Order placed successfully!");
    }

    public void backButtonOnAction(ActionEvent e){
        adminPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("idorder"));
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        idBloodCol.setCellValueFactory(new PropertyValueFactory<>("idbloodgroup"));
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        contactNumberCol.setCellValueFactory(new PropertyValueFactory<>("contactnumber"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));

    }



    public void adminPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

}
