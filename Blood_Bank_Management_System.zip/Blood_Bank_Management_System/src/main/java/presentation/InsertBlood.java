package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.bloodgroupsavailable;
import model.registeredblooddonors;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertBlood {

    @FXML
    private Button insertButton;
    @FXML
    private TextField idDonorTxt;
    @FXML
    private TextField bloodGrTxt;
    @FXML
    private TextField bloodRHTxt;
    @FXML
    private TextField stockTxt;
    @FXML
    private Label label;

    GenericDAO<bloodgroupsavailable> genericDAO = new GenericDAO<>();

    public void insertButtonOnAction(ActionEvent e){

        if(idDonorTxt.getText().isBlank() == false && bloodGrTxt.getText().isBlank() == false && bloodRHTxt.getText().isBlank()==false && stockTxt.getText().isBlank()==false){
            insert();
            Stage stage = (Stage) insertButton.getScene().getWindow();
            stage.close();
        }else{
            label.setText("Please fill in the fields!");
        }



    }

    public boolean validateBlood(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from bloodgroupsavailable WHERE idgroup = " + Integer.parseInt(idDonorTxt.getText()) + " AND bloodgroup = '" + bloodGrTxt.getText() + "' AND bloodrh = '" + bloodRHTxt.getText() + "' AND stock = " + Integer.parseInt(stockTxt.getText());
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("This blood group has already been registered!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public void insert(){
        int id = Integer.parseInt(idDonorTxt.getText());
        String blGr = bloodGrTxt.getText();
        String blRH = bloodRHTxt.getText();
        int st = Integer.parseInt(stockTxt.getText());

        if(!validateBlood()) {
            bloodgroupsavailable bl = new bloodgroupsavailable(id, blGr, blRH, st);
            genericDAO.insertWithoutId(bl);
            label.setText("Item inserted successfully!");
        }
    }


}
