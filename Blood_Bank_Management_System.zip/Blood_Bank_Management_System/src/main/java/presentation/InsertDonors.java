package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.registeredblooddonors;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class InsertDonors {

    @FXML
    private TextField firstNameTxt;
    @FXML
    private TextField lastNameTxt;
    @FXML
    private TextField blGroupTxt;
    @FXML
    private TextField blRhTxt;
    @FXML
    private TextField phoneNRTxt;
    @FXML
    private TextField addressTxt;
    @FXML
    private TextField emailTxt;
    @FXML
    private Button insertButton;

    @FXML
    private Label label;

    GenericDAO<registeredblooddonors> genericDAO = new GenericDAO<>();


    @FXML
    private void insertButtonOnAction(ActionEvent e){
        if(firstNameTxt.getText().isBlank() == false && lastNameTxt.getText().isBlank() == false && blGroupTxt.getText().isBlank()==false && blRhTxt.getText().isBlank()==false&&phoneNRTxt.getText().isBlank()==false&&emailTxt.getText().isBlank()==false&&addressTxt.getText().isBlank()==false){
            label.setText(" ");
            insertItem();
            Stage stage = (Stage) insertButton.getScene().getWindow();
            stage.close();
        }else{
            label.setText("Please fill in the fields!");
        }

    }


    public void insertItem(){
        String firstName = firstNameTxt.getText();
        String lastName = lastNameTxt.getText();
        String blGr = blGroupTxt.getText();
        String blRH = blRhTxt.getText();
        String phone = phoneNRTxt.getText();
        String email = emailTxt.getText();
        String address = addressTxt.getText();

        if(!validateDonor()){
            registeredblooddonors donor = new registeredblooddonors(firstName, lastName, blGr, blRH, phone, address, email);
            genericDAO.insertWithoutId(donor);
            label.setText("Item inserted successfully!");
        }
    }
    public boolean validateDonor(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from registeredblooddonors WHERE firstname = '" + firstNameTxt.getText() + "' AND lastname = '" + lastNameTxt.getText() + "' AND phonenumber = '" + phoneNRTxt.getText() + "' AND email = '" + emailTxt + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("This blood donors has already been registered!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }



}
