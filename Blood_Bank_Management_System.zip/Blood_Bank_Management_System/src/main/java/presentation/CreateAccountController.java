package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class CreateAccountController {

    @FXML
    private TextField usernameTxtField;
    @FXML
    private PasswordField passwordTxtField;
    @FXML
    private TextField emailTxtField;
    @FXML
    private Button myButton;

//    public CreateAccountInterface(Connection connection, AdminSeeAccountsInterface adminSeeAccountsInterface) throws SQLException {
//
//        CreateAccountInterface cInt = this;
//        AdminDAO adminDAO = new AdminDAO(connection, cInt, adminSeeAccountsInterface);
//        ClientDAO clientDAO = new ClientDAO(connection, cInt, adminSeeAccountsInterface);
//        MedicalAssistantDAO medicalAssistantDAO = new MedicalAssistantDAO(connection, cInt, adminSeeAccountsInterface);
//    }
//
//    public TextField getUsernameTxtField() {
//        return usernameTxtField;
//    }
//
//    public void setUsernameTxtField(TextField usernameTxtField) {
//        this.usernameTxtField = usernameTxtField;
//    }
//
//    public PasswordField getPasswordTxtField() {
//        return passwordTxtField;
//    }
//
//    public void setPasswordTxtField(PasswordField passwordTxtField) {
//        this.passwordTxtField = passwordTxtField;
//    }
//
//    public TextField getEmailTxtField() {
//        return emailTxtField;
//    }
//
//    public void setEmailTxtField(TextField emailTxtField) {
//        this.emailTxtField = emailTxtField;
//    }

    private String username;
    private String password;
    private String email;


    public void getInput(ActionEvent event){

        username = usernameTxtField.getText();
        password = passwordTxtField.getText();
        email = emailTxtField.getText();
        System.out.println(username + " " + password + " " + email);


    }


}
