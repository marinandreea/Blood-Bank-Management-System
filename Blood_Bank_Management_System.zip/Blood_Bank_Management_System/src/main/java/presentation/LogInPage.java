package presentation;

import javafx.event.ActionEvent;

public class LogInPage {
    public void pressButton(ActionEvent event) {
        System.out.println("Hello");
    }
}
