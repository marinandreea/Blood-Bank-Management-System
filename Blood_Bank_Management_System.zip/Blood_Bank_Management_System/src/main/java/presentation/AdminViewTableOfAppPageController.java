package presentation;

import connection.ConnectionFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Appointment;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class AdminViewTableOfAppPageController implements Initializable {

    @FXML
    private TableView<Appointment> table;
    @FXML
    private TableColumn<Appointment, Integer> idCol;
    @FXML
    private TableColumn<Appointment, Integer> idBloodDonorCol;
    @FXML
    private TableColumn<Appointment, String> dateCol;
    @FXML
    private TableColumn<Appointment, String> hourCol;
    @FXML
    private Button listButton;
    @FXML
    private Button backButton;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<Appointment> list = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void listButtonOnAction(ActionEvent e) throws SQLException {
        list.clear();
        query = "SELECT * from appointment";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            Appointment app = new Appointment(resultSet.getInt("id"), resultSet.getInt("idblooddonor"), resultSet.getString("date"), resultSet.getString("hour"));
            list.add(app);
            table.setItems(list);

        }
    }

    public void backButtonOnAction(ActionEvent e){
        adminPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idBloodDonorCol.setCellValueFactory(new PropertyValueFactory<>("idblooddonor"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        hourCol.setCellValueFactory(new PropertyValueFactory<>("hour"));

    }

    public void adminPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
