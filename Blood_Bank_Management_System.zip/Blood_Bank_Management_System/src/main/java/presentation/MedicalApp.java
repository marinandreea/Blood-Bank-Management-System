package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Appointment;

import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class MedicalApp implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private Button insertButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button refreshButton;
    @FXML
    private TableView<Appointment> table;
    @FXML
    private TableColumn<Appointment, Integer> idCol;
    @FXML
    private TableColumn<Appointment, Integer> idBloodDonorCol;
    @FXML
    private TableColumn<Appointment, String> dateCol;
    @FXML
    private TableColumn<Appointment, String> hourCol;
    @FXML
    private Label label;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<Appointment> list = FXCollections.observableArrayList();
    GenericDAO<Appointment> genericDAO = new GenericDAO<>();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void backButtonOnAction(ActionEvent e){
        goToMedPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void insertButtonOnAction(ActionEvent e){
        goToInsertPage();
    }

    public void deleteButtonOnAction(ActionEvent e){

        Appointment app = table.getSelectionModel().getSelectedItem();
        genericDAO.delete(app);
        label.setText("Item deleted successfully!");

    }

    public void updateButtonOnAction(ActionEvent e){
        goToUpdatePage();
    }

    public void refreshButtonOnAction(ActionEvent e) throws SQLException {
        display();
    }
    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idBloodDonorCol.setCellValueFactory(new PropertyValueFactory<>("idblooddonor"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        hourCol.setCellValueFactory(new PropertyValueFactory<>("hour"));

    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from appointment";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            Appointment app = new Appointment(resultSet.getInt("id"), resultSet.getInt("idblooddonor"), resultSet.getString("date"), resultSet.getString("hour"));
            list.add(app);
            table.setItems(list);

        }
    }

    public void goToMedPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-assistant-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void goToInsertPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("insert-app.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void goToUpdatePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("update-app.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }



}
