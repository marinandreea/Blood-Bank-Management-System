package presentation;

import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TableView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.EventHandler;

public class AdminSeeAccountController {

    @FXML
    private TableView table;

    @FXML
    private final Button viewAdmin = new Button("View list of created accounts for admin");

    public TableView getTable() {
        return table;
    }

    public void setTable(TableView table) {
        this.table = table;
    }



}
