package presentation;

import connection.ConnectionFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class RecoverPasswordController {

    @FXML
    private TextField emailTxtField;
    @FXML
    private Button okButton;
    @FXML
    private Button backButton;
    @FXML
    private Label label;

    public void okButtonOnAction(ActionEvent e){

        if(emailTxtField.getText().isBlank() == false){
                validateEmailA();
                if(!label.getText().equals("A message containing the password will be send to this email!")){
                    validateEmailC();
                    if(!label.getText().equals("A message containing the password will be send to this email!")){
                        validateEmailMA();
                    }
                }


        }else{
            label.setText("Please enter your email!");
        }
    }

    public void backButtonOnAction(ActionEvent e){

        backToLogInPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void validateEmailA() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query1 = "SELECT count(1) from admin WHERE email = '" + emailTxtField.getText() + "'";

        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);

            while (resultSet1.next()) {
                if (resultSet1.getInt(1) == 1) {
                    label.setText("A message containing the password will be send to this email!");

                } else {
                    label.setText("Incorrect email! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void validateEmailC() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query2 = "SELECT count(1) from client WHERE email = '" + emailTxtField.getText() + "'";

        try {
            Statement statement2 = connection.createStatement();
            ResultSet resultSet2 = statement2.executeQuery(query2);

            while (resultSet2.next()) {
                if (resultSet2.getInt(1) == 1) {
                    label.setText("A message containing the password will be send to this email!");

                } else {
                    label.setText("Incorrect email! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void validateEmailMA() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query3 = "SELECT count(1) from medicalassistant WHERE email = '" + emailTxtField.getText() + "'";

        try {

            Statement statement3 = connection.createStatement();
            ResultSet resultSet3 = statement3.executeQuery(query3);

            while (resultSet3.next()) {
                if (resultSet3.getInt(1) == 1) {
                    label.setText("A message containing the password will be send to this email!");

                } else {
                    label.setText("Incorrect email! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void backToLogInPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("log-in-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }


}
