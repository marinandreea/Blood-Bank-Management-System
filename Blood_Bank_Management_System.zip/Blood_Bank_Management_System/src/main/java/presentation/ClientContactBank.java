package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.OrderBlood;
import model.bloodgroupsavailable;

import java.sql.*;
import java.util.Objects;

public class ClientContactBank {

    @FXML
    private Button backButton;
    @FXML
    private Button contactButton;
    @FXML
    private TextField firstNameTxt;
    @FXML
    private TextField lastNameTxt;
    @FXML
    private TextField bloodGrTxt;
    @FXML
    private TextField blRhTxt;
    @FXML
    private TextField stockTxt;
    @FXML
    private TextField addressTxt;
    @FXML
    private TextField contactNrTxt;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    GenericDAO<bloodgroupsavailable> genericDAO = new GenericDAO<>();
    GenericDAO<OrderBlood> genericDAO2 = new GenericDAO<>();
    ClientPageController clientPageController = new ClientPageController();



    public void backButtonOnAction(ActionEvent e){
        clientPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void contactButtonOnAction(ActionEvent e) throws SQLException {
        connection = ConnectionFactory.getConnection();
        contactB();


    }

    public int getBlGroupId() throws SQLException {
        String blGr = bloodGrTxt.getText();
        String blRH = blRhTxt.getText();
        int id = 0;

        query = "SELECT idgroup FROM bloodgroupsavailable WHERE bloodgroup = '" + blGr + "' AND bloodrh = '" + blRH + "'";
        Statement statement1 = connection.createStatement();
        ResultSet resultSet1 = statement1.executeQuery(query);
        if(resultSet1.next()){
            id = resultSet1.getInt("idgroup");}


        return id;

    }
    public int getStock() throws SQLException {
        String blGr = bloodGrTxt.getText();
        String blRH = blRhTxt.getText();
        int stockk = 0;

        query = "SELECT stock FROM bloodgroupsavailable WHERE bloodgroup = '" + blGr + "' AND bloodrh = '" + blRH + "'";
        Statement statement1 = connection.createStatement();
        ResultSet resultSet1 = statement1.executeQuery(query);
        if(resultSet1.next()) {
            stockk = resultSet1.getInt("stock");
        }

        return stockk;

    }
    public bloodgroupsavailable getBlood() throws SQLException {
        String blGr = bloodGrTxt.getText();
        String blRH = blRhTxt.getText();
        bloodgroupsavailable item = null;

        query = "SELECT * FROM bloodgroupsavailable WHERE bloodgroup = '" + blGr + "' AND bloodrh = '" + blRH + "'";
        Statement statement1 = connection.createStatement();
        ResultSet resultSet1 = statement1.executeQuery(query);
        if(resultSet1.next()){
             item = new bloodgroupsavailable(resultSet1.getInt("idgroup"), resultSet1.getInt("iddonor"), resultSet1.getString("bloodgroup"), resultSet1.getString("bloodrh"), resultSet1.getInt("stock"));

        }

        return item;

    }

    public void contactB() throws SQLException {

        int idGroup = getBlGroupId();
        String firstName = firstNameTxt.getText();
        String lastName = lastNameTxt.getText();
        String stock = stockTxt.getText();
        String address = addressTxt.getText();
        String contactNr = contactNrTxt.getText();
        int stockBlood  = getStock();
        bloodgroupsavailable gr = getBlood();

        if(idGroup == 0 || stockBlood == 0 || gr == null){
            clientPage();
            clientPageController.showMess7();
        }else if(Integer.parseInt(stock) <= stockBlood){
            OrderBlood orderBlood = new OrderBlood(firstName, lastName, idGroup, Integer.parseInt(stock), contactNr, address);
            gr.setStock(stockBlood - Integer.parseInt(stock));
            genericDAO.update2(gr);
            genericDAO2.insertWithoutId(orderBlood);
            clientPage();
            clientPageController.showMess5();

        }else{
            showMess6();
        }

    }
    public void showMess6(){
        Alert alert  = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(":(");
        alert.setContentText("Quantity is bigger than our available stock at the moment!");
        alert.showAndWait();
    }


    public void clientPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }




}
