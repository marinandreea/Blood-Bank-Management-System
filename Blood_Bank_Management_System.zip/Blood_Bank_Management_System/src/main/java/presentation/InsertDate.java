package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import model.dateappointment;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertDate {

    @FXML
    private Button insertButton;
    @FXML
    private TextField dayTxt;
    @FXML
    private TextField monthTxt;
    @FXML
    private TextField yearTxt;
    @FXML
    private TextField hourTxt;
    @FXML
    private Label label;

    GenericDAO<dateappointment> genericDAO = new GenericDAO<>();

    public void insertButtonOnAction(ActionEvent e){

        if(dayTxt.getText().isBlank()==false && monthTxt.getText().isBlank()==false && yearTxt.getText().isBlank()==false && hourTxt.getText().isBlank()==false ){
            insert();
            Stage stage = (Stage) insertButton.getScene().getWindow();
            stage.close();
        }else{
            label.setText("Please fill in the fields!");
        }

    }

    public boolean validateDate(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from dateappointment WHERE day = " + Integer.parseInt(dayTxt.getText()) + " AND month = " + Integer.parseInt(monthTxt.getText()) + " AND year = " +Integer.parseInt(yearTxt.getText()) + " AND hour = '" + hourTxt.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("This date has already been registered!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public void insert(){
        int day = Integer.parseInt(dayTxt.getText());
        int month = Integer.parseInt(monthTxt.getText());
        int year = Integer.parseInt(yearTxt.getText());
        String hour = hourTxt.getText();

        if(!validateDate()){
            dateappointment dapp = new dateappointment(day, month, year, hour);
            genericDAO.insertWithoutId(dapp);
            label.setText("Item inserted successfully!");

        }
    }


}
