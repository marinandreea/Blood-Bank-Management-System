package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.Objects;

public class MedicalAssistantController {

    @FXML
    private Button backButton;
    @FXML
    private Button donorsButton;
    @FXML
    private Button bloodButton;
    @FXML
    private Button appButton;
    @FXML
    private Button datesButton;

    public void backButtonOnAction(ActionEvent e){
        homePage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void donorsButtonOnAction(ActionEvent e){
       donorsPage();
        Stage stage = (Stage) donorsButton.getScene().getWindow();
        stage.close();
    }
    public void bloodButtonOnAction(ActionEvent e){
        bloodPage();
        Stage stage = (Stage) bloodButton.getScene().getWindow();
        stage.close();
    }
    public void appButtonOnAction(ActionEvent e){
        appPage();
        Stage stage = (Stage) appButton.getScene().getWindow();
        stage.close();
    }
    public void datesButtonOnAction(ActionEvent e){
        datesPage();
        Stage stage = (Stage) datesButton.getScene().getWindow();
        stage.close();
    }


    public void homePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("start-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void bloodPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-assistant-access-blood.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void donorsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-assistant-table-donors.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void appPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-appointments.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void datesPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-dates.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }


}
