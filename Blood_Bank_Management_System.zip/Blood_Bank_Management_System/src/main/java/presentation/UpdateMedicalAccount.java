package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.medicalassistant;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UpdateMedicalAccount implements Initializable {


    @FXML
    private TextField emailTxtField;
    @FXML
    private PasswordField passwordTxtField;
    @FXML
    private Label label;
    @FXML
    private Button updateButton;
    @FXML
    private TableView<medicalassistant> table;
    @FXML
    private TableColumn<medicalassistant, String> usernameCol;
    @FXML
    private TableColumn<medicalassistant, String> passwordCol;
    @FXML
    private TableColumn<medicalassistant, String> emailCol;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;


    GenericDAO<medicalassistant> genericDAO = new GenericDAO<>();
    ObservableList<medicalassistant> list = FXCollections.observableArrayList();

    public void updateButtonOnAction(ActionEvent e){


        updateItem();
        Stage stage = (Stage) updateButton.getScene().getWindow();
        stage.close();


    }

    public void updateItem(){


        String password = passwordTxtField.getText();
        String email = emailTxtField.getText();
        medicalassistant ad = table.getSelectionModel().getSelectedItem();
        if( passwordTxtField.getText().isBlank() == false && emailTxtField.getText().isBlank() == true){

            ad.setPassword(password);
        }else if( passwordTxtField.getText().isBlank() == true && emailTxtField.getText().isBlank() == false){

            ad.setEmail(email);

        }else{

            ad.setPassword(password);
            ad.setEmail(email);
        }

//        ad.setUsername(username);
//        ad.setPassword(password);
//        ad.setEmail(email);
        genericDAO.update(ad);
        label.setText("Item updated successfully!");

    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));


    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from medicalassistant";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            medicalassistant medicalAssistant = new medicalassistant(resultSet.getString("username"), resultSet.getString("password"), resultSet.getString("email"));
            list.add(medicalAssistant);
            //table.setItems(list);

        }
        table.setItems(list);
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
