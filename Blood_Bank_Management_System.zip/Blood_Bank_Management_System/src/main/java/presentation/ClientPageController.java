package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.control.Alert;

import java.util.Objects;

public class ClientPageController {

    @FXML
    private Button backButton;
    @FXML
    private Button registerDonorButton;
    @FXML
    private Button seeListOfDonorsButton;
    @FXML
    private Button seeListBloodButton;
    @FXML
    private Button makeAnAppButton;
    @FXML
    private Button contactBankButton;




    public void backButtonOnAction(ActionEvent e){
        logInPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void registerDonorButtonOnAction(ActionEvent e){
        preRegPage();
        Stage stage = (Stage) registerDonorButton.getScene().getWindow();
        stage.close();
    }

    public void seeListOfDonorsButtonOnAction(ActionEvent e){
        seeDonorsPage();
        Stage stage = (Stage) seeListOfDonorsButton.getScene().getWindow();
        stage.close();
    }

    public void seeListBloodButtonOnAction(ActionEvent e){
        seeBloodPage();
        Stage stage = (Stage) seeListBloodButton.getScene().getWindow();
        stage.close();
    }

    public void makeAnAppButtonOnAction(ActionEvent e){
        makeAppPage();
        Stage stage = (Stage) makeAnAppButton.getScene().getWindow();
        stage.close();
    }

    public void contactBankButtonOnAction(ActionEvent e){
        contactPage();
        Stage stage = (Stage) contactBankButton.getScene().getWindow();
        stage.close();
    }

    public void logInPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("log-in-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void showMess(){
        Alert alert  = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(":(");
        alert.setContentText("Unfortunately you do not meet the necessary criteria to be a donor!");
        alert.showAndWait();
    }

    public void showMess2(){
        Alert alert  = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(":)");
        alert.setContentText("Congratulations! you successfully registered as donor!");
        alert.showAndWait();
    }

    public void showMess3(){
        Alert alert  = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(":(");
        alert.setContentText("Please register as a donor first!");
        alert.showAndWait();
    }
    public void showMess4(){
        Alert alert  = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(":)");
        alert.setContentText("Your appointment was booked successfully!");
        alert.showAndWait();
    }
    public void showMess5(){
        Alert alert  = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(":)");
        alert.setContentText("Your order was registered successfully!");
        alert.showAndWait();
    }

    public void showMess7(){
        Alert alert  = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(":(");
        alert.setContentText("This blood group is not available at the moment!");
        alert.showAndWait();
    }



    public void preRegPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("pre-registration.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void seeDonorsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-see-list-donors.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void seeBloodPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-see-list-blood.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void makeAppPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-book-appointment.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void contactPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-contact-bank.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

}
