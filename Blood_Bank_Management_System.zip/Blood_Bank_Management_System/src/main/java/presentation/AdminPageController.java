package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;


import java.util.Objects;

public class AdminPageController {

    @FXML
    private Button backButton;
    @FXML
    private Button viewTableOfDonorsButton;
    @FXML
    private Button viewTableOfBloodButton;
    @FXML
    private Button accessTableOfOrdersButton;
    @FXML
    private Button viewTableOfAppointmentsButton;
    @FXML
    private Button accessTableOfAccountsButton;

    public void backButtonOnAction(ActionEvent e){
        homePage();Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void viewTableOfDonorsButtonOnAction(ActionEvent e){
        viewTableOfDonorsPage();
        Stage stage = (Stage) viewTableOfDonorsButton.getScene().getWindow();
        stage.close();
    }

    public void viewTableOfBloodButtonOnAction(ActionEvent e){
        viewListOfBloodPage();
        Stage stage = (Stage) viewTableOfBloodButton.getScene().getWindow();
        stage.close();
    }

    public void accessTableOfOrdersButtonOnAction(ActionEvent e){
        accessOrdersPage();
        Stage stage = (Stage) accessTableOfOrdersButton.getScene().getWindow();
        stage.close();
    }

    public void viewTableOfAppointmentsButtonOnAction(ActionEvent e){
        viewListOfAppointmentsPage();
        Stage stage = (Stage) viewTableOfAppointmentsButton.getScene().getWindow();
        stage.close();
    }

    public void accessTableOfAccountsButtonOnAction(ActionEvent e){
        accessAccountsPage();
        Stage stage = (Stage) accessTableOfAccountsButton.getScene().getWindow();
        stage.close();
    }

    public void homePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("start-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void viewTableOfDonorsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-see-list-donors.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void viewListOfBloodPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-see-list-blood.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void accessOrdersPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-access-order.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void accessAccountsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-view-accounts.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void viewListOfAppointmentsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-view-appointments.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

}
