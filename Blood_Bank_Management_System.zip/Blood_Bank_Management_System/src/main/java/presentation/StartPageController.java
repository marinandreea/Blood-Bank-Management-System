package presentation;

import connection.ConnectionFactory;
import dataAccess.AdminDAO;
import javafx.event.ActionEvent;

import java.sql.Connection;
import java.sql.SQLException;

public class StartPageController {

    AdminSeeAccountController adminSeeAccountsInterface;
    CreateAccountController createAccountController;
    AdminDAO adminDAO;

    public StartPageController(AdminSeeAccountController adminSeeAccountsInterface, CreateAccountController createAccountController) throws SQLException {
       Connection connection = ConnectionFactory.getConnection();
        if(connection != null){
            System.out.println("Connected!");
        }
        adminDAO = new AdminDAO(connection, createAccountController, adminSeeAccountsInterface);
        this.adminSeeAccountsInterface = adminSeeAccountsInterface;
        this.createAccountController = createAccountController;


    }

    public void pressButton(ActionEvent event) throws SQLException {
         adminDAO.displayAdmin();
    }

}
