package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.admin;
import model.client;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class AccountsClientController implements Initializable {

    @FXML
    private Button displayButton;
    @FXML
    private Button backButton;
    @FXML
    private TableView<client> table;
    @FXML
    private TableColumn<client, String> usernameCol;
    @FXML
    private TableColumn<client, String> passwordCol;
    @FXML
    private TableColumn<client, String> emailCol;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;



    ObservableList<client> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
        passwordCol.setCellValueFactory(new PropertyValueFactory<>("password"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));


    }



    public void backButtonOnAction(ActionEvent e){

        viewAccountsPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void viewAccountsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-view-accounts.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void displayButtonOnAction(ActionEvent e) throws SQLException {
        display();
    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from client";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            client cl = new client(resultSet.getString("username"), resultSet.getString("passwrd"), resultSet.getString("email"));
            list.add(cl);
            //table.setItems(list);

        }
        table.setItems(list);
    }
}
