package presentation;

import connection.ConnectionFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.bloodgroupsavailable;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class AdminViewTableOfBloodPageController implements Initializable {

    @FXML
    private TableView<bloodgroupsavailable> table;
    @FXML
    private TableColumn<bloodgroupsavailable, Integer> idGroupCol;
    @FXML
    private TableColumn<bloodgroupsavailable, Integer> idDonorCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> bloodGroupCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> bloodRhCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> stockCol;

    @FXML
    private Button listButton;
    @FXML
    private Button backButton;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<bloodgroupsavailable> list = FXCollections.observableArrayList();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void listButtonOnAction(ActionEvent e) throws SQLException {
        list.clear();
        query = "SELECT * from bloodgroupsavailable";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            bloodgroupsavailable blGroup = new bloodgroupsavailable(resultSet.getInt("idgroup"), resultSet.getInt("iddonor"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getInt("stock") );
            list.add(blGroup);
            table.setItems(list);

        }
    }

    public void backButtonOnAction(ActionEvent e){
        adminPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idGroupCol.setCellValueFactory(new PropertyValueFactory<>("idgroup"));
        idDonorCol.setCellValueFactory(new PropertyValueFactory<>("iddonor"));
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodgroup"));
        bloodRhCol.setCellValueFactory(new PropertyValueFactory<>("bloodrh"));
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
    }

    public void adminPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
