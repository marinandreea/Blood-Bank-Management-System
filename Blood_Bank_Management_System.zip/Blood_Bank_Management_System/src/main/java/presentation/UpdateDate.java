package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import model.dateappointment;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UpdateDate implements Initializable {

    @FXML
    private Button updateButton;
    @FXML
    private TextField dayTxt;
    @FXML
    private TextField monthTxt;
    @FXML
    private TextField yearTxt;
    @FXML
    private TextField hourTxt;
    @FXML
    private TableView<dateappointment> table;
    @FXML
    private TableColumn<dateappointment, Integer> idCol;
    @FXML
    private TableColumn<dateappointment, Integer> dayCol;
    @FXML
    private TableColumn<dateappointment, Integer> monthCol;
    @FXML
    private TableColumn<dateappointment, Integer> yearCol;
    @FXML
    private TableColumn<dateappointment, String> hourCol;
    @FXML
    private Label label;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<dateappointment> list = FXCollections.observableArrayList();
    GenericDAO<dateappointment> genericDAO = new GenericDAO<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateButtonOnAction(ActionEvent e){
        update();
        Stage stage = (Stage) updateButton.getScene().getWindow();
        stage.close();
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        dayCol.setCellValueFactory(new PropertyValueFactory<>("day"));
        monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));
        hourCol.setCellValueFactory(new PropertyValueFactory<>("hour"));

    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from dateappointment";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            dateappointment app = new dateappointment(resultSet.getInt("id"), resultSet.getInt("day"),resultSet.getInt("month"),resultSet.getInt("year"), resultSet.getString("hour"));
            list.add(app);
            table.setItems(list);

        }
    }

    public void update(){
        ;

        dateappointment dapp = table.getSelectionModel().getSelectedItem();

        if(dayTxt.getText().isBlank() == false){
            int day = Integer.parseInt(dayTxt.getText());
            dapp.setDay(day);
        }
        if(monthTxt.getText().isBlank()==false){
            int month = Integer.parseInt(monthTxt.getText());
            dapp.setMonth(month);
        }
        if(yearTxt.getText().isBlank()==false){
            int year = Integer.parseInt(yearTxt.getText());
            dapp.setYear(year);
        }
        if(hourTxt.getText().isBlank()==false){
            String hour = hourTxt.getText();
            dapp.setHour(hour);
        }

        genericDAO.update2(dapp);
        label.setText("Item updated successfully!");

    }
}
