package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.client;

import java.sql.*;
import java.util.Objects;

public class RegisterController {

    @FXML
    private Button registerButton;
    @FXML
    private Button backButton;
    @FXML
    private TextField usernameTxtField;
    @FXML
    private TextField emailTxtField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField passwordField2;
    @FXML
    private Label label;

    GenericDAO<client> genericDAO = new GenericDAO<client>();

    public void backButtonOnAction(ActionEvent e){
        homePage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void registerButtonOnAction(ActionEvent e) throws SQLException {

        if(usernameTxtField.getText().isBlank() == false && emailTxtField.getText().isBlank() == false && passwordField.getText().isBlank() == false && passwordField2.getText().isBlank() == false){
            label.setText("Please fill in the fields!");
            register();
        }else{
            label.setText("You must fill in all the fields in order to create an account!");
        }

    }

    public void register() throws SQLException {

        String username = usernameTxtField.getText();
        String email = emailTxtField.getText();
        String password1 = passwordField.getText();
        String password2 = passwordField2.getText();


        if(!validateEmail() && !validateUsername() && !validatePassword()){
            if(password1.equals(password2)){
                client clientt = new client(username, password1, email);
                genericDAO.insert(clientt);
                label.setText("Account created successfully!");
                usernameTxtField.setText("");
                emailTxtField.setText("");
                passwordField.setText("");
                passwordField2.setText("");
                logInPage();

            }else{
                label.setText("Passwords do not match! Please try again!");
            }

        }
    }



    public boolean validateUsername(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from client WHERE username = '" + usernameTxtField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


                if (resultSet1.next()) {
                    ok = true;
                    label.setText("Please try another username!");
                } else {

                    ok = false;
                }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public boolean validatePassword(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from client WHERE passwrd = '" + passwordField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


                if (resultSet1.next()) {
                    ok = true;
                    label.setText("Please try another password!");
                } else {

                    ok = false;
                }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;

    }

    public boolean validateEmail(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from client WHERE email = '" + emailTxtField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


                if (resultSet1.next()) {
                    ok = true;
                    label.setText("Please try another email!");
                } else {

                    ok = false;
                }



        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;

    }

    public void homePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("start-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void logInPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("log-in-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

}
