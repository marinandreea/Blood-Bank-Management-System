package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.admin;
import model.registeredblooddonors;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Objects;
import java.util.ResourceBundle;

public class MedAssDonorsTable implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private Button insertButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button refreshButton;
    @FXML
    private TableView<registeredblooddonors> table;
    @FXML
    private TableColumn<registeredblooddonors, Integer> idCol;
    @FXML
    private TableColumn<registeredblooddonors, String> firstNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> lastNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodGroupCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodRhCol;
    @FXML
    private TableColumn<registeredblooddonors, String> phoneNrCol;
    @FXML
    private TableColumn<registeredblooddonors, String> addressCol;
    @FXML
    private TableColumn<registeredblooddonors, String> emailCol;
    @FXML
    private Label label;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<registeredblooddonors> list = FXCollections.observableArrayList();
    GenericDAO<registeredblooddonors> genericDAO = new GenericDAO<>();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void backButtonOnAction(ActionEvent e){
        goToMedPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void insertButtonOnAction(ActionEvent e){
        goToInsertPage();
    }

    public void deleteButtonOnAction(ActionEvent e){

        registeredblooddonors reg = table.getSelectionModel().getSelectedItem();
        genericDAO.delete(reg);
        label.setText("Item deleted successfully!");

    }

    public void updateButtonOnAction(ActionEvent e){

        //ad = table.getSelectionModel().getSelectedItem();
        //genericDAO.deleteAccount(admin);
        goToUpdatePage();
    }

    public void refreshButtonOnAction(ActionEvent e) throws SQLException {

        list.clear();
        query = "SELECT * from registeredblooddonors";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            registeredblooddonors donor = new registeredblooddonors(resultSet.getInt("id"), resultSet.getString("firstname"), resultSet.getString("lastname"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getString("phonenumber"), resultSet.getString("address"), resultSet.getString("email") );
            list.add(donor);
            table.setItems(list);

        }
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodgroup"));
        bloodRhCol.setCellValueFactory(new PropertyValueFactory<>("bloodrh"));
        phoneNrCol.setCellValueFactory(new PropertyValueFactory<>("phonenumber"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from registeredblooddonors";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            registeredblooddonors donor = new registeredblooddonors(resultSet.getInt("id"), resultSet.getString("firstname"), resultSet.getString("lastname"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getString("phonenumber"), resultSet.getString("address"), resultSet.getString("email") );
            list.add(donor);
            table.setItems(list);

        }
    }
    public void goToInsertPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("insert-donors.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void goToMedPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-assistant-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void goToUpdatePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("update-donors.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }




}
