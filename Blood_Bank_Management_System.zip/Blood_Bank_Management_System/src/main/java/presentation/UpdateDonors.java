package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.admin;
import model.registeredblooddonors;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UpdateDonors implements Initializable {


    @FXML
    private TextField phoneNRTxt;
    @FXML
    private TextField addressTxt;
    @FXML
    private TextField emailTxt;
    @FXML
    private Label label;
    @FXML
    private TableView<registeredblooddonors> table;
    @FXML
    private TableColumn<registeredblooddonors, Integer> idCol;
    @FXML
    private TableColumn<registeredblooddonors, String> firstNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> lastNameCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodGroupCol;
    @FXML
    private TableColumn<registeredblooddonors, String> bloodRhCol;
    @FXML
    private TableColumn<registeredblooddonors, String> phoneNrCol;
    @FXML
    private TableColumn<registeredblooddonors, String> addressCol;
    @FXML
    private TableColumn<registeredblooddonors, String> emailCol;
    @FXML
    private Button updateButton;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;


    GenericDAO<registeredblooddonors> genericDAO = new GenericDAO<>();
    ObservableList<registeredblooddonors> list = FXCollections.observableArrayList();





    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from registeredblooddonors";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            registeredblooddonors donor = new registeredblooddonors(resultSet.getInt("id"), resultSet.getString("firstname"), resultSet.getString("lastname"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getString("phonenumber"), resultSet.getString("address"), resultSet.getString("email") );
            list.add(donor);
            table.setItems(list);

        }
    }


    public void updateButtonOnAction(ActionEvent e){
        updateItem();
        Stage stage = (Stage) updateButton.getScene().getWindow();
        stage.close();
    }
    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodgroup"));
        bloodRhCol.setCellValueFactory(new PropertyValueFactory<>("bloodrh"));
        phoneNrCol.setCellValueFactory(new PropertyValueFactory<>("phonenumber"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
    }

    public void updateItem(){


        String phone = phoneNRTxt.getText();
        String email = emailTxt.getText();
        String address = addressTxt.getText();

        registeredblooddonors ad = table.getSelectionModel().getSelectedItem();
        if(phoneNRTxt.getText().isBlank() == false && emailTxt.getText().isBlank() == true && addressTxt.getText().isBlank() == true) {
            ad.setPhonenumber(phone);
        }else if(phoneNRTxt.getText().isBlank() == false && emailTxt.getText().isBlank() == false && addressTxt.getText().isBlank() == true){
            ad.setPhonenumber(phone);
            ad.setEmail(email);
        }else if(phoneNRTxt.getText().isBlank() == false && emailTxt.getText().isBlank() == true && addressTxt.getText().isBlank() == false){
            ad.setPhonenumber(phone);
            ad.setEmail(email);
        }else if(phoneNRTxt.getText().isBlank() == true && emailTxt.getText().isBlank() == false && addressTxt.getText().isBlank() == true){
            ad.setEmail(email);
        }else if(phoneNRTxt.getText().isBlank() == true && emailTxt.getText().isBlank() == false && addressTxt.getText().isBlank() == false){
            ad.setAddress(address);
            ad.setEmail(email);
        }else if(phoneNRTxt.getText().isBlank() == true && emailTxt.getText().isBlank() == true && addressTxt.getText().isBlank() == false){
            ad.setAddress(address);
        }else{
            ad.setPhonenumber(phone);
            ad.setAddress(address);
            ad.setEmail(email);
        }

        genericDAO.update2(ad);
        label.setText("Item updated successfully!");


    }
}
