package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.bloodgroupsavailable;
import model.registeredblooddonors;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class UpdateBlood implements Initializable {

    @FXML
    private Button updateButton;
    @FXML
    private TextField stockTxt;
    @FXML
    private TableView<bloodgroupsavailable> table;
    @FXML
    private TableColumn<bloodgroupsavailable, Integer> idGroupCol;
    @FXML
    private TableColumn<bloodgroupsavailable, Integer> idDonorCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> bloodGroupCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> bloodRhCol;
    @FXML
    private TableColumn<bloodgroupsavailable, String> stockCol;

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;

    ObservableList<bloodgroupsavailable> list = FXCollections.observableArrayList();
    GenericDAO<bloodgroupsavailable> genericDAO = new GenericDAO<>();


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void updateButtonOnAction(ActionEvent e){
        update();
        Stage stage = (Stage) updateButton.getScene().getWindow();
        stage.close();
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        idGroupCol.setCellValueFactory(new PropertyValueFactory<>("idgroup"));
        idDonorCol.setCellValueFactory(new PropertyValueFactory<>("iddonor"));
        bloodGroupCol.setCellValueFactory(new PropertyValueFactory<>("bloodgroup"));
        bloodRhCol.setCellValueFactory(new PropertyValueFactory<>("bloodrh"));
        stockCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from bloodgroupsavailable";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            bloodgroupsavailable blGroup = new bloodgroupsavailable(resultSet.getInt("idgroup"), resultSet.getInt("iddonor"), resultSet.getString("bloodgroup"), resultSet.getString("bloodrh"), resultSet.getInt("stock") );
            list.add(blGroup);
            table.setItems(list);

        }
    }

    public void update(){
        int st = Integer.parseInt(stockTxt.getText());

        bloodgroupsavailable gr = table.getSelectionModel().getSelectedItem();

        gr.setStock(st);
        genericDAO.update2(gr);


    }
}
