package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.medicalassistant;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertMedicalAccount {

    @FXML
    private TextField usernameTxtField;
    @FXML
    private TextField emailTxtField;
    @FXML
    private PasswordField passwordTxtField;
    @FXML
    private PasswordField password2TxtField;
    @FXML
    private Button insertButton;
    @FXML
    private Label label;

    GenericDAO<medicalassistant> genericDAO = new GenericDAO<>();

    public void insertButtonOnAction(ActionEvent e){
        if(usernameTxtField.getText().isBlank() == false && passwordTxtField.getText().isBlank() == false && password2TxtField.getText().isBlank() == false && emailTxtField.getText().isBlank() == false){
            label.setText(" ");
            insertItem();
            Stage stage = (Stage) insertButton.getScene().getWindow();
            stage.close();

        }else{
            label.setText("Please fill in the fields!");
        }


    }

    public void insertItem(){
        String username = usernameTxtField.getText();
        String password = passwordTxtField.getText();
        String password2 = password2TxtField.getText();
        String email = emailTxtField.getText();

        if(!validateEmail() && !validateUsername() && !validatePassword()){
            if(password.equals(password2)){
                medicalassistant medicalAssistant = new medicalassistant(username, password, email);
                genericDAO.insert(medicalAssistant);
                label.setText("Item inserted successfully!");
            }else{
                label.setText("Password do not match! Please try again!");
            }
        }
    }

    public boolean validateUsername(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from medicalassistant WHERE username = '" + usernameTxtField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("Please try another username!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public boolean validatePassword(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from medicalassistant WHERE password = '" + passwordTxtField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("Please try another password!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;

    }

    public boolean validateEmail(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from medicalassistant WHERE email = '" + emailTxtField.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("Please try another email!");
            } else {

                ok = false;
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;

    }

}
