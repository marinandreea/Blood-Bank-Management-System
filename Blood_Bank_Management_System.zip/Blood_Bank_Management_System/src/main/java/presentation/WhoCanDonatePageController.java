package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.Objects;

public class WhoCanDonatePageController {

    @FXML
    private Button homeButton;
    @FXML
    private Button whyToDonateButton;
    @FXML
    private Button donationProcessButton;
    @FXML
    private Button logInButton;

    public void homeButtonOnAction(ActionEvent e){
        homePage();
        Stage stage = (Stage) homeButton.getScene().getWindow();
        stage.close();
    }

    public void homePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("start-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }


    public void whyToDonateButtonOnAction(ActionEvent e){

        whyToDonatePage();
        Stage stage = (Stage) whyToDonateButton.getScene().getWindow();
        stage.close();

    }

    public void donationProcessButtonOnAction(ActionEvent e){

        donationProcessPage();
        Stage stage = (Stage) donationProcessButton.getScene().getWindow();
        stage.close();

    }

    public void logInButtonOnAction(ActionEvent e){

        logInPage();
        Stage stage = (Stage) logInButton.getScene().getWindow();
        stage.close();

    }

    public void logInPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("log-in-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void whyToDonatePage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("why-to-donate.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void donationProcessPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("donation-process.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
