package presentation;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.Objects;

public class ClientPreReg {

    @FXML
    private Button backButton;
    @FXML
    private Button submitButton;
    @FXML
    private RadioButton n4;
    @FXML
    private RadioButton y1;
    @FXML
    private RadioButton n1;
    @FXML
    private RadioButton y2;
    @FXML
    private RadioButton n2;
    @FXML
    private RadioButton y3;
    @FXML
    private RadioButton n3;
    @FXML
    private RadioButton y4;

    ClientPageController clientPageController = new ClientPageController();
    ClientRegDonor clientRegDonor = new ClientRegDonor();

    public void backButtonOnAction(ActionEvent e){

        clientPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void submitButtonOnAction(ActionEvent e){

        if(y1.isSelected() && n2.isSelected() && n3.isSelected() && n4.isSelected()){

            registerPage();
            clientRegDonor.showMess();
            Stage stage = (Stage) submitButton.getScene().getWindow();
            stage.close();

        }else{
            clientPage();
            clientPageController.showMess();
            Stage stage = (Stage) submitButton.getScene().getWindow();
            stage.close();
        }

    }

    public void registerPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("register-as-donor.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void clientPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }


}
