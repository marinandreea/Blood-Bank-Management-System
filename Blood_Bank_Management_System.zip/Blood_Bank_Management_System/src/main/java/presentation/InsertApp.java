package presentation;

import connection.ConnectionFactory;
import dataAccess.GenericDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Appointment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertApp {

    @FXML
    private Button insertButton;
    @FXML
    private TextField idDonorTxt;
    @FXML
    private TextField dateTxt;
    @FXML
    private TextField hourTxt;
    @FXML
    private Label label;

    GenericDAO<Appointment> genericDAO = new GenericDAO<>();

    public void insertButtonOnAction(ActionEvent e){

        if(idDonorTxt.getText().isBlank() == false && dateTxt.getText().isBlank()==false && hourTxt.getText().isBlank()==false){
            insert();
            Stage stage = (Stage) insertButton.getScene().getWindow();
            stage.close();
        }else{
            label.setText("Please fill in the fields!");
        }

    }

    public boolean validateApp(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT * from appointment WHERE idblooddonor = " + Integer.parseInt(idDonorTxt.getText()) + " AND date = '" + dateTxt.getText() + "' AND hour = '" + hourTxt.getText() + "'";
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;
                label.setText("This appointment has already been registered!");
            } else {

                ok = false;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public boolean validateIdDonor(){

        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();
        boolean ok = false;

        String query1 = "SELECT id from registeredblooddonors WHERE id = " + Integer.parseInt(idDonorTxt.getText());
        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);


            if (resultSet1.next()) {
                ok = true;

            } else {

                ok = false;
                label.setText("There is no blood donor having this id!");
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return ok;
    }

    public void insert(){
        int idDonor = Integer.parseInt(idDonorTxt.getText());
        String date = dateTxt.getText();
        String hour = hourTxt.getText();

        if(validateIdDonor() && !validateApp()){
            Appointment app = new Appointment(idDonor, date, hour);
            genericDAO.insertWithoutId(app);
            label.setText("Item inserted successfully!");

        }
    }






}
