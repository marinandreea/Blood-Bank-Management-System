package presentation;

import connection.ConnectionFactory;
import dataAccess.dateappointment;
import dataAccess.GenericDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.Appointment;

import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class ClientMakeApp implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private Button bookAppButton;
    @FXML
    private TableView<dateappointment> table;
    @FXML
    private TableColumn<dateappointment, Integer> dayCol;
    @FXML
    private TableColumn<dateappointment, Integer> monthCol;
    @FXML
    private TableColumn<dateappointment, Integer> yearCol;
    @FXML
    private TableColumn<dateappointment, String> hourCol;
    @FXML
    private TextField firstNameTxt;
    @FXML
    private TextField lastNameTxt;


    ObservableList<dateappointment> list = FXCollections.observableArrayList();
    GenericDAO<Appointment> genericDAO = new GenericDAO<>();
    GenericDAO<dateappointment> genericDAO2 = new GenericDAO<>();
    ClientPageController clientPageController = new ClientPageController();

    String query = null;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;


    public void backButtonOnAction(ActionEvent e){
        clientPage();Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();
    }

    public void bookAppButtonOnAction(ActionEvent e){
        bookApp();
    }

    public void bookApp(){
        String firstName = firstNameTxt.getText();
        String lastName = lastNameTxt.getText();
        int idApp;

        query = "SELECT id FROM registeredblooddonors WHERE firstname = '" + firstName + "' AND lastname = '" + lastName + "';";

        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query);


            if (resultSet1.next()) {
                idApp = resultSet1.getInt("id");
                dateappointment dateappointment = table.getSelectionModel().getSelectedItem();
                //Date d = new Date(dateForApp.getYear(), dateForApp.getMonth(), dateForApp.getDay());


                String hour = dateappointment.getHour();
                String dd = dateappointment.getDay() + "/" + dateappointment.getMonth() + "/" + dateappointment.getYear();

                Appointment  app = new Appointment(idApp, dd, hour);
                genericDAO.insertWithoutId(app);
                clientPage();
                clientPageController.showMess4();
                String query2 = "SELECT id FROM dateappointment WHERE day = " + dateappointment.getDay() + " AND month = " + dateappointment.getMonth() + " AND year = " + dateappointment.getYear() + " AND hour = '" + dateappointment.getHour() + "'";
                Statement statement2 = connection.createStatement();
                ResultSet resultSet2 = statement1.executeQuery(query2);
                if(resultSet2.next()){
                    dateappointment d = new dateappointment(resultSet2.getInt("id"), dateappointment.getDay(), dateappointment.getMonth(), dateappointment.getYear(), dateappointment.getHour());
                    genericDAO2.delete(d);
                }
                //genericDAO2.delete(dateForApp);

            } else {
                clientPage();
                clientPageController.showMess3();;

            }



        } catch (Exception e) {
            e.printStackTrace();
        }




    }




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            loadData();
            display();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadData() throws SQLException {

        connection = ConnectionFactory.getConnection();

        dayCol.setCellValueFactory(new PropertyValueFactory<>("day"));
        monthCol.setCellValueFactory(new PropertyValueFactory<>("month"));
        yearCol.setCellValueFactory(new PropertyValueFactory<>("year"));
        hourCol.setCellValueFactory(new PropertyValueFactory<>("hour"));

    }

    public void display() throws SQLException {
        list.clear();
        query = "SELECT * from dateappointment";
        preparedStatement = connection.prepareStatement(query);
        resultSet = preparedStatement.executeQuery();

        while(resultSet.next()){

            dateappointment dateappointment = new dateappointment(resultSet.getInt("day"), resultSet.getInt("month"), resultSet.getInt("year"), resultSet.getString("hour"));
            list.add(dateappointment);
            table.setItems(list);

        }
    }
    public void clientPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
