package presentation;

import connection.ConnectionFactory;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class LogInController {

    @FXML
    private TextField usernameTxtField;
    @FXML
    private PasswordField passwordTxtField;
    @FXML
    private TextField emailTxtField;
    @FXML
    private Button logInButton;
    @FXML
    private Button recoverPasswordButton;
    @FXML
    private Button registerButton;
    @FXML
    private Button backButton;
    @FXML
    private Label label;

    public void logInButtonOnAction(ActionEvent e){

        if(usernameTxtField.getText().isBlank() == false && passwordTxtField.getText().isBlank() == false && emailTxtField.getText().isBlank() == false){
            label.setText("Please enter your credentials!");
            validateLogInA();
            if(!label.getText().equals("Welcome!")){
                validateLogInC();
                if(!label.getText().equals("Welcome!")){
                    validateLogInMA();
                }
                Stage stage = (Stage) logInButton.getScene().getWindow();
                stage.close();

            }
        }else{
            label.setText("Please enter your credentials!");
        }

    }

    public void recoverPasswordButtonOnAction(ActionEvent e){

        recoverPasswordPage();
        Stage stage = (Stage) recoverPasswordButton.getScene().getWindow();
        stage.close();

    }

    public void registerButtonOnAction(ActionEvent e){

        registerPage();
        Stage stage = (Stage) registerButton.getScene().getWindow();
        stage.close();

    }

    public void backButtonOnAction(ActionEvent e){

        startPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void validateLogInA() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query1 = "SELECT count(1) from admin WHERE username = '" + usernameTxtField.getText() + "' AND password = '" + passwordTxtField.getText() + "' AND email = '" + emailTxtField.getText() + "'";

        try {
            Statement statement1 = connection.createStatement();
            ResultSet resultSet1 = statement1.executeQuery(query1);

            while (resultSet1.next()) {
                if (resultSet1.getInt(1) == 1) {
                    label.setText("Welcome!");
                    adminPage();

                } else {
                    label.setText("Incorrect credentials! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void validateLogInC() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query2 = "SELECT count(1) from client WHERE username = '" + usernameTxtField.getText() + "' AND passwrd = '" + passwordTxtField.getText() + "' AND email = '" + emailTxtField.getText() + "'";

        try {
            Statement statement2 = connection.createStatement();
            ResultSet resultSet2 = statement2.executeQuery(query2);

            while (resultSet2.next()) {
                if (resultSet2.getInt(1) == 1) {
                    label.setText("Welcome!");
                    clientPage();
                } else {
                    label.setText("Incorrect credentials! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void validateLogInMA() {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Connection connection = connectionFactory.getConnection();

        String query3 = "SELECT count(1) from medicalassistant WHERE username = '" + usernameTxtField.getText() + "' AND password = '" + passwordTxtField.getText() + "' AND email = '" + emailTxtField.getText() + "'";

        try {

            Statement statement3 = connection.createStatement();
            ResultSet resultSet3 = statement3.executeQuery(query3);

            while (resultSet3.next()) {
                if (resultSet3.getInt(1) == 1) {
                    label.setText("Welcome!");
                    medicalAssistantPage();
                } else {
                    label.setText("Incorrect credentials! Please try again!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void adminPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void clientPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("client-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void medicalAssistantPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("medical-assistant-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void recoverPasswordPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("recover-password.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void registerPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("register-in-app.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void startPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("start-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }





}
