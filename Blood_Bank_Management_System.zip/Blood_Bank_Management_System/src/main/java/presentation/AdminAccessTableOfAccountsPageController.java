package presentation;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.BufferedWriter;
import java.util.Objects;

public class AdminAccessTableOfAccountsPageController {

    @FXML
    private Button backButton;
    @FXML
    private Button adminButton;
    @FXML
    private Button medicalAssistantButton;
    @FXML
    private Button clientButton;

    public void backButtonOnAction(ActionEvent e){

        adminPage();
        Stage stage = (Stage) backButton.getScene().getWindow();
        stage.close();

    }

    public void adminButtonOnAction(ActionEvent e){

        adminAccountsPage();
        Stage stage = (Stage) adminButton.getScene().getWindow();
        stage.close();

    }

    public void medicalAssistantButtonOnAction(ActionEvent e){

        medicalAssistantAccountsPage();
        Stage stage = (Stage) medicalAssistantButton.getScene().getWindow();
        stage.close();

    }

    public void clientButtonOnAction(ActionEvent e){

        clientAccountsPage();
        Stage stage = (Stage) clientButton.getScene().getWindow();
        stage.close();

    }

    public void adminPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("admin-page.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void adminAccountsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("accounts-admin.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void medicalAssistantAccountsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("accounts-medical.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void clientAccountsPage(){
        try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("accounts-client.fxml")));
            Stage adminPageStage = new Stage();
            adminPageStage.initStyle(StageStyle.DECORATED);
            adminPageStage.setScene(new Scene(root, 900, 800));
            adminPageStage.show();

        }catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

}
