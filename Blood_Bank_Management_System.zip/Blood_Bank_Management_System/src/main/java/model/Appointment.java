package model;

public class Appointment {

    private int id;
    private int idblooddonor;
    private String date;
    private String hour;

    public Appointment(int id, int idblooddonor, String date) {
        this.id = id;
        this.idblooddonor = idblooddonor;
        this.date = date;

    }

    public Appointment(int id, int idblooddonor, String date, String hour) {
        this.id = id;
        this.idblooddonor = idblooddonor;
        this.date = date;
        this.hour = hour;

    }

    public Appointment(int idblooddonor, String date, String hour) {

        this.idblooddonor = idblooddonor;
        this.date = date;
        this.hour = hour;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdblooddonor() {
        return idblooddonor;
    }

    public void setIdblooddonor(int idblooddonor) {
        this.idblooddonor = idblooddonor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }
}
