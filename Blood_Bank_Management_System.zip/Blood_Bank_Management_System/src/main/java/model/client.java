package model;

public class client {

    private String username;
    private String passwrd;
    private String email;

    public client(String username, String password, String email) {
        this.username = username;
        this.passwrd = password;
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return passwrd;
    }

    public void setPassword(String passwrd) {
        this.passwrd = passwrd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
