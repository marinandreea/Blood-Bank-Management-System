package model;

public class registeredblooddonors {

    private int id;
    private String firstname;
    private String lastname;
    private String bloodgroup;
    private String bloodrh;
    private String phonenumber;
    private String address;
    private String email;

    public registeredblooddonors(int id, String firstName, String lastName, String bloodgroup, String bloodrh, String phonenumber, String address, String email) {
        this.id = id;
        this.firstname = firstName;
        this.lastname = lastName;
        this.bloodgroup = bloodgroup;
        this.bloodrh = bloodrh;
        this.phonenumber = phonenumber;
        this.address = address;
        this.email = email;
    }

    public registeredblooddonors(String firstName, String lastName, String bloodgroup, String bloodrh, String phonenumber, String address, String email) {

        this.firstname = firstName;
        this.lastname = lastName;
        this.bloodgroup = bloodgroup;
        this.bloodrh = bloodrh;
        this.phonenumber = phonenumber;
        this.address = address;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstname;
    }

    public void setFirstName(String firstName) {
        this.firstname = firstName;
    }

    public String getLastName() {
        return lastname;
    }

    public void setLastName(String lastName) {
        this.lastname = lastName;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getBloodrh() {
        return bloodrh;
    }

    public void setBloodrh(String bloodrh) {
        this.bloodrh = bloodrh;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
