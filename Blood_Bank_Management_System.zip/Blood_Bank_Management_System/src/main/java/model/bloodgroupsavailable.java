package model;

public class bloodgroupsavailable {

    private int idgroup;
    private int iddonor;
    private String bloodgroup;
    private String bloodrh;
    private int stock;

    public bloodgroupsavailable(int idgroup, int iddonor, String bloodgroup, String bloodrh, int stock) {
        this.idgroup = idgroup;
        this.iddonor = iddonor;
        this.bloodgroup = bloodgroup;
        this.bloodrh = bloodrh;
        this.stock = stock;
    }

    public bloodgroupsavailable( int iddonor, String bloodgroup, String bloodrh, int stock) {

        this.iddonor = iddonor;
        this.bloodgroup = bloodgroup;
        this.bloodrh = bloodrh;
        this.stock = stock;
    }

    public int getIdgroup() {
        return idgroup;
    }

    public void setIdgroup(int idgroup) {
        this.idgroup = idgroup;
    }

    public int getIddonor() {
        return iddonor;
    }

    public void setIddonor(int iddonor) {
        this.iddonor = iddonor;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getBloodrh() {
        return bloodrh;
    }

    public void setBloodrh(String bloodrh) {
        this.bloodrh = bloodrh;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
