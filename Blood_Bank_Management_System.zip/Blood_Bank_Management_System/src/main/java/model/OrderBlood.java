package model;

public class OrderBlood {

    private int idorder;
    private String firstName;
    private String lastName;
    private int idbloodgroup;
    private int stock;
    private String contactnumber;
    private String address;

    public OrderBlood(int idorder, String firstName, String lastName, int idbloodgroup, int stock, String contactnumber, String address) {
        this.idorder = idorder;
        this.firstName = firstName;
        this.lastName = lastName;
        this.idbloodgroup = idbloodgroup;
        this.stock = stock;
        this.contactnumber = contactnumber;
        this.address = address;
    }

    public OrderBlood(String firstName, String lastName, int idbloodgroup, int stock, String contactnumber, String address) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.idbloodgroup = idbloodgroup;
        this.stock = stock;
        this.contactnumber = contactnumber;
        this.address = address;
    }

    public int getIdorder() {
        return idorder;
    }

    public void setIdorder(int idorder) {
        this.idorder = idorder;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getIdbloodgroup() {
        return idbloodgroup;
    }

    public void setIdbloodgroup(int idbloodgroup) {
        this.idbloodgroup = idbloodgroup;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getContactnumber() {
        return contactnumber;
    }

    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
