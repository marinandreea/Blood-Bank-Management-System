package dataAccess;

import connection.ConnectionFactory;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.TableView;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * @param <T> T can be any Java Model Class that is
 * mapped to the Database, and has the same name as the table and the same instance variables and data types as
 * the table fields
 */
public class GenericDAO<T> {


    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for insertion and executes it
     */
    public void insert(Object obj){

        StringBuilder query = new StringBuilder();
        StringBuilder values = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("INSERT INTO " + obj.getClass().getSimpleName() + " (");
        try{
            for(int i = 0;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);

                if(i != fields.length - 1){

                    query.append(fields[i].getName()).append(", ");
                    if(fields[i].getType().getSimpleName().equals("String")){
                        values.append("'").append(v).append("'").append(", ");
                    }else{
                        values.append(v).append(", ");
                    }
                }else{
                    query.append(fields[i].getName());
                    if(fields[i].getType().getSimpleName().equals("String")){
                        values.append("'").append(v).append("'");
                    }else{
                        values.append(v);
                    }
                }
            }
            query.append(") VALUES " + "(").append(values).append(");");
            System.out.println(query.toString());
        }catch (IllegalAccessException e) {
            //JOptionPane.showMessageDialog(null, "Error at inserting");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
           // JOptionPane.showMessageDialog(null, "Record created successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing insert query");
        }
    }

    public void insertWithoutId(Object obj){

        StringBuilder query = new StringBuilder();
        StringBuilder values = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("INSERT INTO " + obj.getClass().getSimpleName() + " (");
        try{
            for(int i = 1;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);

                if(i != fields.length - 1){

                    query.append(fields[i].getName()).append(", ");
                    if(fields[i].getType().getSimpleName().equals("String")){
                        values.append("'").append(v).append("'").append(", ");
                    }else{
                        values.append(v).append(", ");
                    }
                }else{
                    query.append(fields[i].getName());
                    if(fields[i].getType().getSimpleName().equals("String")){
                        values.append("'").append(v).append("'");
                    }else{
                        values.append(v);
                    }
                }
            }
            query.append(") VALUES " + "(").append(values).append(");");
            System.out.println(query.toString());
        }catch (IllegalAccessException e) {
            //JOptionPane.showMessageDialog(null, "Error at inserting");

        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            // JOptionPane.showMessageDialog(null, "Record created successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing insert query");
        }
    }




    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for deletion and executes it
     */
    public void delete(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        fields[0].setAccessible(true);
        query.append("DELETE FROM " + obj.getClass().getSimpleName() + " WHERE " );
        query.append(fields[0].getName()).append("=");
        try{
            Object v = fields[0].get(obj);
            query.append(v).append(";");
            //System.out.println(query);
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at getting id value");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            //System.out.println(query);
            //JOptionPane.showMessageDialog(null, "Record deleted successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing delete query");
        }

    }

    public void deleteAccount(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        fields[0].setAccessible(true);
        query.append("DELETE FROM " + obj.getClass().getSimpleName() + " WHERE " );
        query.append(fields[0].getName()).append("=");
        try{
            Object v = fields[0].get(obj);
            query.append("'").append(v).append("'").append(";");
            System.out.println(query);
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at getting id value");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            System.out.println(query);
            //JOptionPane.showMessageDialog(null, "Record deleted successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing delete query");
        }

    }

    /**
     * @param obj obj can be a client, product or order
     *
     * The method creates the corresponding query for update and executes it
     */
    public void update(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("UPDATE " + obj.getClass().getSimpleName() + " SET ");
        try{
            for(int i = 0;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);
                query.append(fields[i].getName()).append("=");
                if(i != fields.length - 1){
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'").append(", ");
                    }else{
                        query.append(v).append(", ");
                    }
                }else{
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'");
                    }else{
                        query.append(v);
                    }
                }
            }
            query.append(" WHERE ");
            fields[0].setAccessible(true);
            query.append(fields[0].getName()).append("=");
            Object v = fields[0].get(obj);
            query.append("'").append(v + "';");

            System.out.println(query);
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at updating");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            //JOptionPane.showMessageDialog(null, "Record updated successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing update query");
        }
    }

    public void update2(Object obj){

        StringBuilder query = new StringBuilder();
        Field[] fields = obj.getClass().getDeclaredFields();
        query.append("UPDATE " + obj.getClass().getSimpleName() + " SET ");
        try{
            for(int i = 0;i < fields.length; i++){

                fields[i].setAccessible(true);
                Object v = fields[i].get(obj);
                query.append(fields[i].getName()).append("=");
                if(i != fields.length - 1){
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'").append(", ");
                    }else{
                        query.append(v).append(", ");
                    }
                }else{
                    if(fields[i].getType().getSimpleName().equals("String")){
                        query.append("'").append(v).append("'");
                    }else{
                        query.append(v);
                    }
                }
            }
            query.append(" WHERE ");
            fields[0].setAccessible(true);
            query.append(fields[0].getName()).append("=");
            Object v = fields[0].get(obj);
            query.append(v + ";");
            System.out.println(query);
        } catch (IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, "Error at updating");
        }
        try{
            Connection connection = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(query.toString());
            preparedStatement.executeUpdate();
            ConnectionFactory.close(connection);
            ConnectionFactory.close(preparedStatement);
            //JOptionPane.showMessageDialog(null, "Record updated successfully!");
        } catch (Exception e) {
            System.out.println("Exception when executing update query");
            System.out.println(query);
        }
    }


}



