package dataAccess;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import model.medicalassistant;
import presentation.AdminSeeAccountController;
import presentation.CreateAccountController;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MedicalAssistantDAO extends GenericDAO<medicalassistant>{

    private CreateAccountController createAccountController;
    private AdminSeeAccountController adminSeeAccountsInterface;
    private Statement medStatement;
    private Connection medConnection;
    private final ObservableList<medicalassistant> medAssistants = FXCollections.observableArrayList(medicalAssistantList());

    public MedicalAssistantDAO(Connection medConnection, CreateAccountController createAccountController, AdminSeeAccountController adminSeeAccountsInterface) throws SQLException {
        this.medConnection = medConnection;
        this.createAccountController = createAccountController;
        this.adminSeeAccountsInterface = adminSeeAccountsInterface;
        try{
            this.medStatement = medConnection.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public ArrayList<medicalassistant> medicalAssistantList() throws SQLException {

        ArrayList<medicalassistant> medList = new ArrayList<>();
        ResultSet rs = medStatement.executeQuery("SELECT * FROM medicalassistant");
        while(rs.next()){
            medicalassistant m = new medicalassistant(rs.getString("username"), rs.getString("password"), rs.getString("email"));
            medList.add(m);
        }
        return medList;
    }

    public void displayAssitant() throws SQLException{

        TableColumn username = new TableColumn("Username");
        username.setCellValueFactory(new PropertyValueFactory<medicalassistant, String>("username"));
        TableColumn password = new TableColumn("Password");
        password.setCellValueFactory(new PropertyValueFactory<medicalassistant, String>("password"));
        TableColumn email = new TableColumn("Email");
        email.setCellValueFactory(new PropertyValueFactory<medicalassistant, String>("email"));

        //adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);

        adminSeeAccountsInterface.getTable().setItems(medAssistants);
        adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);
    }

//    public void insertAssistant() throws SQLException{
//
//        String assistantUsername = createAccountInterface.getUsernameTxtField().getText();
//        String assistantPassword = createAccountInterface.getPasswordTxtField().getText();
//        String assistantEmail = createAccountInterface.getEmailTxtField().getText();
//
//        MedicalAssistant m = new MedicalAssistant(assistantUsername, assistantPassword, assistantEmail);
//        medAssistants.add(m);
//        insert(m);
//    }
}
