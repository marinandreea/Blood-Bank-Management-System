package dataAccess;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import model.admin;
import presentation.AdminSeeAccountController;
import presentation.CreateAccountController;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AdminDAO extends GenericDAO<admin>{

    private CreateAccountController createAccountController;
    private AdminSeeAccountController adminSeeAccountsInterface;
    private Statement adminStatement;
    private Connection adminConnection;
    private final ObservableList<admin> admins = FXCollections.observableArrayList(adminList());

    public AdminDAO(Connection adminConnection, CreateAccountController createAccountController, AdminSeeAccountController adminSeeAccountsInterface) throws SQLException {
        this.adminConnection = adminConnection;
        this.createAccountController = createAccountController;
        this.adminSeeAccountsInterface = adminSeeAccountsInterface;
        try{
            this.adminStatement = adminConnection.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public ArrayList<admin> adminList() throws SQLException {

        ArrayList<admin> admList = new ArrayList<>();
        ResultSet rs = adminStatement.executeQuery("SELECT * FROM admin");
        while(rs.next()){
            admin admin = new admin(rs.getString("username"), rs.getString("password"), rs.getString("email"));
            admList.add(admin);
        }
        return admList;
    }

    public void displayAdmin() throws SQLException{

        TableColumn username = new TableColumn("Username");
        username.setCellValueFactory(new PropertyValueFactory<admin, String>("username"));
        TableColumn password = new TableColumn("Password");
        password.setCellValueFactory(new PropertyValueFactory<admin, String>("password"));
        TableColumn email = new TableColumn("Email");
        email.setCellValueFactory(new PropertyValueFactory<admin, String>("email"));

        //adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);

        adminSeeAccountsInterface.getTable().setItems(admins);
        adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);
    }

//    public void insertAdmin() throws SQLException{
//
//        String adminUsername = createAccountInterface.getUsernameTxtField().getText();
//        String adminPassword = createAccountInterface.getPasswordTxtField().getText();
//        String adminEmail = createAccountInterface.getEmailTxtField().getText();
//
//        Admin ad = new Admin(adminUsername, adminPassword, adminEmail);
//        admins.add(ad);
//        insert(ad);
//    }
}
