package dataAccess;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import model.client;
import presentation.AdminSeeAccountController;
import presentation.CreateAccountController;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ClientDAO extends GenericDAO<client>{

    private CreateAccountController createAccountController;
    private AdminSeeAccountController adminSeeAccountsInterface;
    private Statement clientStatement;
    private Connection clientConnection;
    private final ObservableList<client> clients = FXCollections.observableArrayList(clientList());

    public ClientDAO(Connection clientConnection, CreateAccountController createAccountController, AdminSeeAccountController adminSeeAccountsInterface) throws SQLException {
        this.clientConnection = clientConnection;
        this.createAccountController = createAccountController;
        this.adminSeeAccountsInterface = adminSeeAccountsInterface;
        try{
            this.clientStatement = clientConnection.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public ArrayList<client> clientList() throws SQLException {

        ArrayList<client> clientList = new ArrayList<>();
        ResultSet rs = clientStatement.executeQuery("SELECT * FROM client");
        while(rs.next()){
            client client = new client(rs.getString("username"), rs.getString("password"), rs.getString("email"));
            clientList.add(client);
        }
        return clientList;
    }

    public void displayClient() throws SQLException{

        TableColumn username = new TableColumn("Username");
        username.setCellValueFactory(new PropertyValueFactory<client, String>("username"));
        TableColumn password = new TableColumn("Password");
        password.setCellValueFactory(new PropertyValueFactory<client, String>("password"));
        TableColumn email = new TableColumn("Email");
        email.setCellValueFactory(new PropertyValueFactory<client, String>("email"));

        //adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);

        adminSeeAccountsInterface.getTable().setItems(clients);
        adminSeeAccountsInterface.getTable().getColumns().addAll(username, password, email);
    }

//    public void insertClient() throws SQLException{
//
//        String clientUsername = createAccountInterface.getUsernameTxtField().getText();
//        String clientPassword = createAccountInterface.getPasswordTxtField().getText();
//        String clientEmail = createAccountInterface.getEmailTxtField().getText();
//
//        Client c = new Client(clientUsername, clientPassword, clientEmail);
//        clients.add(c);
//        insert(c);
//    }
}
